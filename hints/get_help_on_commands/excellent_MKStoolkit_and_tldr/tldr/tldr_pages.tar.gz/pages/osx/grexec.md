# grexec

> This command is an alias of GNU `rexec`.

- View documentation for the original command:

`tldr -p linux rexec`
