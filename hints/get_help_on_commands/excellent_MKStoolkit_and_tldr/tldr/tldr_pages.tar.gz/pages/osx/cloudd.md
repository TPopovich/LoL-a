# cloudd

> Backs the CloudKit feature.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/cloudd.8.html>.

- Start the daemon:

`cloudd`
