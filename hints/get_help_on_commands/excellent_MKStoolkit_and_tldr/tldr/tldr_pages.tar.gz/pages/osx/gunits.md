# gunits

> This command is an alias of GNU `units`.

- View documentation for the original command:

`tldr -p linux units`
