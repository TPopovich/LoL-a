# gwhois

> This command is an alias of GNU `whois`.

- View documentation for the original command:

`tldr -p linux whois`
