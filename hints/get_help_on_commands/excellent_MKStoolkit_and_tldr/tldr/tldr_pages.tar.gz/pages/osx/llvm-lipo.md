# llvm-lipo

> This command is an alias of `lipo`.

- View documentation for the original command:

`tldr lipo`
