# gsync

> This command is an alias of GNU `sync`.

- View documentation for the original command:

`tldr -p linux sync`
