# gdircolors

> This command is an alias of GNU `dircolors`.

- View documentation for the original command:

`tldr -p linux dircolors`
