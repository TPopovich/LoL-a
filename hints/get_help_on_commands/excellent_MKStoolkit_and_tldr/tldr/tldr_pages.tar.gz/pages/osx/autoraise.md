# AutoRaise

> Automatically raise and/or focus a window when hovering over it with the mouse.
> More information: <https://github.com/sbmpost/AutoRaise>.

- Run AutoRaise in the background:

`autoraise &`
