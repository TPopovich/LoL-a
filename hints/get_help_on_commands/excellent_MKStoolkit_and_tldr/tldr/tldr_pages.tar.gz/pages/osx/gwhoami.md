# gwhoami

> This command is an alias of GNU `whoami`.

- View documentation for the original command:

`tldr -p linux whoami`
