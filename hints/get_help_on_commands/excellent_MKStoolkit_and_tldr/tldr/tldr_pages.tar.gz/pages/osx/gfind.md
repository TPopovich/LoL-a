# gfind

> This command is an alias of GNU `find`.

- View documentation for the original command:

`tldr -p linux find`
