# gtimeout

> This command is an alias of GNU `timeout`.

- View documentation for the original command:

`tldr -p linux timeout`
