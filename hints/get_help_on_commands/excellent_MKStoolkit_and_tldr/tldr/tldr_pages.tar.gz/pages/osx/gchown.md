# gchown

> This command is an alias of GNU `chown`.

- View documentation for the original command:

`tldr -p linux chown`
