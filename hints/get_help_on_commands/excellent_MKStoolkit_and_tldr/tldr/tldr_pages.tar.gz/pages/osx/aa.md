# aa

> This command is an alias of `yaa`.

- View documentation for the original command:

`tldr yaa`
