# gdd

> This command is an alias of GNU `dd`.

- View documentation for the original command:

`tldr -p linux dd`
