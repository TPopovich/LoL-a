# biomesyncd

> Synchronizes data between devices registered to the same account.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/biomesyncd.8.html>.

- Start the daemon:

`biomesyncd`
