# gtruncate

> This command is an alias of GNU `truncate`.

- View documentation for the original command:

`tldr -p linux truncate`
