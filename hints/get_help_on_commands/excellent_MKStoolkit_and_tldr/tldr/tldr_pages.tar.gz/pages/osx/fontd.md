# fontd

> Make fonts available to the system.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/fontd.8.html>.

- Start the daemon:

`fontd`
