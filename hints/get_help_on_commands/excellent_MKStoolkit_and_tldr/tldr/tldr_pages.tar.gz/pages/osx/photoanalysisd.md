# photoanalysisd

> Analyze photo libraries for Memories, People, and scene or object based search.
> `photoanalysisd` should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/photoanalysisd.8.html>.

- Start the daemon:

`photoanalysisd`
