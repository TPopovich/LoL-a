# sl

> In PowerShell, this command is an alias of `Set-Location`.

- View documentation for the original command:

`tldr set-location`
