# cuninst

> This command is an alias of `choco uninstall`.

- View documentation for the original command:

`tldr choco uninstall`
