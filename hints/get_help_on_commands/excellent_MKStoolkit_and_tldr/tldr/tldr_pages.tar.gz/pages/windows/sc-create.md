# sc create

> This command is an alias of `sc.exe create`.

- View documentation for the original command:

`tldr sc`
