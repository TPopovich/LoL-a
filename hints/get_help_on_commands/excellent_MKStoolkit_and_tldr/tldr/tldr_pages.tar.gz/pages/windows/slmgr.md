# slmgr

> This command is an alias of `slmgr.vbs`.

- View documentation for the original command:

`tldr slmgr.vbs`
