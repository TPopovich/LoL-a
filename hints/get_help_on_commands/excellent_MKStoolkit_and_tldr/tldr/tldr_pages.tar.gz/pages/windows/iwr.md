# iwr

> In PowerShell, this command is an alias of `Invoke-WebRequest`.

- View documentation for the original command:

`tldr invoke-webrequest`
