# sc delete

> This command is an alias of `sc.exe delete`.

- View documentation for the original command:

`tldr sc`
