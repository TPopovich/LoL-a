# ri

> In PowerShell, this command is an alias of `Remove-Item`.

- View documentation for the original command:

`tldr remove-item`
