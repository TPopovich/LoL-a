# mi

> In PowerShell, this command is an alias of `Move-Item`.

- View documentation for the original command:

`tldr move-item`
