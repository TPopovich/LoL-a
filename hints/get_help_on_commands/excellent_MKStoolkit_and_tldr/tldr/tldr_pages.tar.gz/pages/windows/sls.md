# sls

> This command is an alias of `Select-String`.

- View documentation for the original command:

`tldr select-string`
