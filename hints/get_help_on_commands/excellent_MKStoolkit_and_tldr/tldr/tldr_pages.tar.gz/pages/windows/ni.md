# ni

> In PowerShell, this command is an alias of `New-Item`.

- View documentation for the original command:

`tldr new-item`
